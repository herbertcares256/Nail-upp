-- Nail Upp starter database schema for Supabase/Postgres
create extension if not exists pgcrypto;

create type public.user_role as enum ('customer','technician','parlour','seller','admin');
create type public.booking_status as enum ('pending','accepted','on_the_way','in_progress','completed','cancelled');
create type public.provider_type as enum ('technician','parlour');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  role public.user_role not null default 'customer',
  avatar_url text,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.providers (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references public.profiles(id) on delete cascade,
  provider_type public.provider_type not null,
  business_name text not null,
  description text,
  phone text,
  location_text text,
  latitude double precision,
  longitude double precision,
  home_service boolean not null default false,
  rating numeric(2,1) not null default 0,
  review_count integer not null default 0,
  is_open boolean not null default true,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id) on delete cascade,
  name text not null,
  price_ugx integer not null check(price_ugx >= 0),
  duration_min integer not null default 60,
  active boolean not null default true
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references public.profiles(id) on delete set null,
  provider_id uuid references public.providers(id) on delete set null,
  service_id uuid references public.services(id) on delete set null,
  service_mode text not null check(service_mode in ('home','parlour')),
  address_text text,
  latitude double precision,
  longitude double precision,
  scheduled_at timestamptz not null,
  status public.booking_status not null default 'pending',
  amount_ugx integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid unique references public.bookings(id) on delete cascade,
  customer_id uuid references public.profiles(id) on delete set null,
  provider_id uuid references public.providers(id) on delete cascade,
  rating integer not null check(rating between 1 and 5),
  review_text text,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid references public.profiles(id) on delete set null,
  name text not null,
  category text not null,
  description text,
  price_ugx integer not null check(price_ugx >= 0),
  stock integer not null default 0,
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references public.profiles(id) on delete set null,
  status text not null default 'pending',
  subtotal_ugx integer not null default 0,
  delivery_fee_ugx integer not null default 0,
  total_ugx integer not null default 0,
  delivery_address text,
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  quantity integer not null check(quantity > 0),
  unit_price_ugx integer not null check(unit_price_ugx >= 0)
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references public.profiles(id) on delete set null,
  booking_id uuid references public.bookings(id) on delete set null,
  order_id uuid references public.orders(id) on delete set null,
  provider text not null,
  external_reference text,
  amount_ugx integer not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

-- Basic RLS. Expand with role-aware policies before production.
alter table public.profiles enable row level security;
alter table public.providers enable row level security;
alter table public.services enable row level security;
alter table public.bookings enable row level security;
alter table public.reviews enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;

create policy "public read providers" on public.providers for select using (true);
create policy "public read services" on public.services for select using (true);
create policy "public read products" on public.products for select using (true);

create policy "users read own profile" on public.profiles for select using (auth.uid() = id);
create policy "users update own profile" on public.profiles for update using (auth.uid() = id);
create policy "users insert own profile" on public.profiles for insert with check (auth.uid() = id);

create policy "customers create bookings" on public.bookings for insert with check (auth.uid() = customer_id);
create policy "customers read own bookings" on public.bookings for select using (auth.uid() = customer_id);
create policy "customers create reviews" on public.reviews for insert with check (auth.uid() = customer_id);
create policy "customers read reviews" on public.reviews for select using (true);

create policy "customers create orders" on public.orders for insert with check (auth.uid() = customer_id);
create policy "customers read own orders" on public.orders for select using (auth.uid() = customer_id);
