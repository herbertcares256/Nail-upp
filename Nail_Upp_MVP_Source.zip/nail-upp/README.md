# Nail Upp

Nail Upp is an Uber-style nail-service marketplace MVP for Uganda. It supports customer booking, home-service discovery, parlour discovery, nail-product shopping, technician/parlour/seller dashboards, reviews, and customer care.

## What is included

- React Native + Expo app
- Customer flow
- Technician dashboard
- Parlour dashboard
- Seller dashboard
- Provider profiles
- Home-service booking flow
- Parlour booking flow
- Product shop/cart
- Payment selection screen
- Booking tracking UI
- Customer care page
- Supabase schema for users, providers, services, bookings, reviews, products, orders and payments

## Run it

1. Install Node.js LTS.
2. Install dependencies:
   `npm install`
3. Copy `.env.example` to `.env` and add your Supabase values.
4. In Supabase SQL Editor, run `supabase/schema.sql`.
5. Start:
   `npx expo start`

## Important production work

This repository is a functional MVP foundation, not a production launch by itself. Before publishing, connect:

- Uganda Mobile Money/card payment provider
- Real GPS/location permissions and map SDK
- Real-time technician location updates
- Push notifications
- Image storage for profiles/portfolios/products
- Production role-aware Supabase RLS policies
- Provider identity/business verification
- Order delivery integration
- Admin web dashboard
- Fraud/refund/dispute handling
- Real customer-care phone/WhatsApp/email
- App Store and Google Play signing/configuration

## Customer care

The app reads these from `.env`:

EXPO_PUBLIC_CUSTOMER_CARE_PHONE
EXPO_PUBLIC_CUSTOMER_CARE_WHATSAPP
EXPO_PUBLIC_CUSTOMER_CARE_EMAIL

Replace the placeholders before release.

## Branding

Primary color: #F20B70
Tagline: Beauty at your fingertips
