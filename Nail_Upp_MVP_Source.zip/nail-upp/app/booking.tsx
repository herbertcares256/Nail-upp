import { router, useLocalSearchParams } from "expo-router";
import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
import { colors } from "@/lib/theme";
import { providers, services, money } from "@/lib/mock";

export default function Booking(){
 const {provider,service}=useLocalSearchParams<{provider:string;service:string}>();
 const p=providers.find(x=>x.id===provider)||providers[0]; const sv=services.find(x=>x.id===service)||p.services[0];
 return <ScrollView contentContainerStyle={s.c}><Text style={s.back} onPress={()=>router.back()}>‹ Back</Text><Text style={s.h}>Book {p.role==="parlour"?"a Parlour":"a Technician"}</Text>
 {[["Provider",p.name],["Service",sv.name],["Date","15 August 2026"],["Time","2:00 PM"],["Location",p.role==="parlour"?p.location||"Kampala":"Customer home"]].map(([a,b])=><View style={s.row} key={a}><Text style={s.label}>{a}</Text><Text style={s.value}>{b}</Text></View>)}
 <View style={s.total}><Text style={s.label}>Total</Text><Text style={s.totalv}>{money(sv.price)}</Text></View>
 <Pressable style={s.btn} onPress={()=>router.push({pathname:"/payment",params:{amount:String(sv.price)}})}><Text style={s.btnText}>Confirm Booking</Text></Pressable></ScrollView>
}
const s=StyleSheet.create({c:{padding:20,backgroundColor:colors.bg,flexGrow:1},back:{color:colors.pink,fontWeight:"800",marginBottom:14},h:{fontSize:28,fontWeight:"900",marginBottom:20},row:{backgroundColor:"#fff",padding:16,borderRadius:12,marginBottom:8,flexDirection:"row",justifyContent:"space-between"},label:{fontWeight:"700",color:colors.muted},value:{fontWeight:"900"},total:{padding:18,marginTop:12,flexDirection:"row",justifyContent:"space-between",backgroundColor:colors.pinkLight,borderRadius:14},totalv:{fontSize:18,fontWeight:"900",color:colors.pink},btn:{backgroundColor:colors.pink,padding:16,borderRadius:12,alignItems:"center",marginTop:20},btnText:{color:"#fff",fontWeight:"900"}});