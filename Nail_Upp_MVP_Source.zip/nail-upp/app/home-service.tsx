import { useState } from "react";
import { router } from "expo-router";
import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
import { colors } from "@/lib/theme";
import { services } from "@/lib/mock";

export default function HomeService(){
 const [service,setService]=useState(services[2].id); const [when,setWhen]=useState("Now");
 return <ScrollView contentContainerStyle={s.c}><Text style={s.back} onPress={()=>router.back()}>‹ Back</Text><Text style={s.h}>Get a Nail Technician at Your Home</Text>
 <Text style={s.label}>1. Select service</Text><View style={s.grid}>{services.map(x=><Pressable key={x.id} style={[s.choice,service===x.id&&s.selected]} onPress={()=>setService(x.id)}><Text>{x.name}</Text><Text style={s.small}>{x.price.toLocaleString()} UGX</Text></Pressable>)}</View>
 <Text style={s.label}>2. Where should the technician come?</Text><Pressable style={s.option}><Text>◉  Use current location</Text></Pressable><Pressable style={s.option}><Text>○  Enter address</Text></Pressable>
 <Text style={s.label}>3. When?</Text><Pressable style={s.option} onPress={()=>setWhen("Now")}><Text>{when==="Now"?"◉":"○"}  Now</Text></Pressable><Pressable style={s.option} onPress={()=>setWhen("Schedule for later")}><Text>{when!=="Now"?"◉":"○"}  Schedule for later</Text></Pressable>
 <Pressable style={s.btn} onPress={()=>router.push("/technicians")}><Text style={s.btnText}>Find a Technician</Text></Pressable>
 </ScrollView>
}
const s=StyleSheet.create({c:{padding:22,backgroundColor:colors.bg,flexGrow:1},back:{color:colors.pink,fontWeight:"800",marginBottom:18},h:{fontSize:27,fontWeight:"900",marginBottom:24},label:{fontWeight:"900",fontSize:16,marginTop:18,marginBottom:10},grid:{flexDirection:"row",flexWrap:"wrap",gap:10},choice:{width:"31%",backgroundColor:"#fff",padding:12,borderRadius:12,borderWidth:1,borderColor:colors.border},selected:{borderColor:colors.pink,backgroundColor:colors.pinkLight},small:{fontSize:11,color:colors.muted,marginTop:5},option:{backgroundColor:"#fff",padding:16,borderRadius:12,marginBottom:8},btn:{backgroundColor:colors.pink,padding:16,borderRadius:12,alignItems:"center",marginTop:22},btnText:{color:"#fff",fontWeight:"900"}});