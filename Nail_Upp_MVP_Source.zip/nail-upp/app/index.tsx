import { router } from "expo-router";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { colors } from "@/lib/theme";

export default function Welcome() {
  return (
    <View style={s.container}>
      <View style={s.logoCircle}><Text style={s.logoMark}>NU</Text></View>
      <Text style={s.logo}>Nail Upp</Text>
      <Text style={s.tag}>Beauty at your fingertips</Text>
      <Text style={s.intro}>Book nail services at home, discover nearby parlours, and shop nail materials in one place.</Text>
      <Pressable style={s.primary} onPress={() => router.push("/role")}>
        <Text style={s.primaryText}>Get Started</Text>
      </Pressable>
      <Pressable style={s.secondary} onPress={() => router.push("/login")}>
        <Text style={s.secondaryText}>Log In</Text>
      </Pressable>
    </View>
  );
}
const s=StyleSheet.create({
 container:{flex:1,backgroundColor:colors.bg,alignItems:"center",justifyContent:"center",padding:28},
 logoCircle:{width:92,height:92,borderRadius:46,backgroundColor:colors.pink,alignItems:"center",justifyContent:"center"},
 logoMark:{color:"#fff",fontWeight:"900",fontSize:28},
 logo:{fontSize:42,fontWeight:"900",fontStyle:"italic",color:colors.pink,marginTop:18},
 tag:{fontSize:18,color:colors.text,marginTop:6},
 intro:{textAlign:"center",color:colors.muted,lineHeight:22,marginTop:24,marginBottom:32},
 primary:{backgroundColor:colors.pink,width:"100%",padding:16,borderRadius:14,alignItems:"center"},
 primaryText:{color:"#fff",fontWeight:"800",fontSize:16},
 secondary:{width:"100%",padding:16,borderRadius:14,alignItems:"center",marginTop:12,borderWidth:1,borderColor:colors.pink},
 secondaryText:{color:colors.pink,fontWeight:"800",fontSize:16}
});