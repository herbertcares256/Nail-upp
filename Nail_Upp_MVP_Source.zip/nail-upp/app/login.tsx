import { useState } from "react";
import { router } from "expo-router";
import { View, Text, TextInput, Pressable, StyleSheet, Alert } from "react-native";
import { colors } from "@/lib/theme";
import { supabase } from "@/lib/supabase";

export default function Login(){
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [busy,setBusy]=useState(false);
 async function submit(){
   setBusy(true);
   if(supabase){
     const {error}=await supabase.auth.signInWithPassword({email,password});
     if(error){Alert.alert("Login failed",error.message);setBusy(false);return;}
   }
   setBusy(false); router.replace("/home");
 }
 return <View style={s.c}><Text style={s.logo}>Nail Upp</Text><Text style={s.h}>Welcome back</Text>
 <TextInput style={s.input} placeholder="Email" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail}/>
 <TextInput style={s.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword}/>
 <Pressable style={s.btn} onPress={submit}><Text style={s.btnText}>{busy?"Signing in...":"Log In"}</Text></Pressable>
 <Pressable onPress={()=>router.push("/role")}><Text style={s.link}>Create an account</Text></Pressable>
 </View>
}
const s=StyleSheet.create({c:{flex:1,padding:24,justifyContent:"center",backgroundColor:colors.bg},logo:{fontSize:34,fontWeight:"900",fontStyle:"italic",color:colors.pink,marginBottom:28},h:{fontSize:28,fontWeight:"900",marginBottom:18},input:{backgroundColor:"#fff",borderWidth:1,borderColor:colors.border,borderRadius:12,padding:15,marginBottom:12},btn:{backgroundColor:colors.pink,padding:16,borderRadius:12,alignItems:"center",marginTop:8},btnText:{color:"#fff",fontWeight:"900"},link:{color:colors.pink,textAlign:"center",marginTop:20,fontWeight:"700"}});