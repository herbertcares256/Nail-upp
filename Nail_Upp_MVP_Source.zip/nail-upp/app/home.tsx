import { router, useLocalSearchParams } from "expo-router";
import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
import { colors, shadow } from "@/lib/theme";
import { providers, products, money } from "@/lib/mock";

export default function Home(){
 const {role="customer"}=useLocalSearchParams<{role?:string}>();
 if(role!=="customer") return <Dashboard role={role}/>;
 return <View style={{flex:1,backgroundColor:colors.bg}}><ScrollView contentContainerStyle={s.c}>
 <Text style={s.logo}>Nail Upp</Text><Text style={s.loc}>📍 Kampala, Uganda</Text>
 <Text style={s.h}>What do you need today?</Text>
 <View style={s.actions}>
  <Action icon="🏠" title="Home Service" onPress={()=>router.push("/home-service")}/>
  <Action icon="💅" title="Book Parlour" onPress={()=>router.push("/parlours")}/>
  <Action icon="🛍️" title="Shop" onPress={()=>router.push("/shop")}/>
 </View>
 <Section title="Nearby Nail Parlours" onPress={()=>router.push("/parlours")}/>
 {providers.filter(p=>p.role==="parlour").map(p=><ProviderCard key={p.id} p={p}/>)}
 <Section title="Top Nail Technicians" onPress={()=>router.push("/technicians")}/>
 {providers.filter(p=>p.role==="technician").map(p=><ProviderCard key={p.id} p={p}/>)}
 </ScrollView><Nav/></View>
}
function Action({icon,title,onPress}:{icon:string;title:string;onPress:()=>void}){return <Pressable style={s.action} onPress={onPress}><Text style={{fontSize:26}}>{icon}</Text><Text style={s.actionText}>{title}</Text></Pressable>}
function Section({title,onPress}:{title:string;onPress:()=>void}){return <View style={s.row}><Text style={s.section}>{title}</Text><Pressable onPress={onPress}><Text style={s.link}>See all</Text></Pressable></View>}
function ProviderCard({p}:{p:any}){return <Pressable style={s.card} onPress={()=>router.push({pathname:"/provider",params:{id:p.id}})}><View style={s.avatar}><Text style={{fontSize:28}}>💅</Text></View><View style={{flex:1}}><Text style={s.name}>{p.name}</Text><Text style={s.rating}>⭐ {p.rating} ({p.reviews})</Text><Text style={s.muted}>{p.distance_km} km away • {p.location||"Kampala"}</Text></View><Text style={s.price}>{money(p.services[0].price)}</Text></Pressable>}
function Nav(){return <View style={s.nav}><Text style={s.active}>⌂{"\n"}Home</Text><Pressable onPress={()=>router.push("/bookings")}><Text style={s.navt}>▣{"\n"}Bookings</Text></Pressable><Pressable onPress={()=>router.push("/technicians")}><Text style={s.navt}>⌕{"\n"}Explore</Text></Pressable><Pressable onPress={()=>router.push("/shop")}><Text style={s.navt}>▢{"\n"}Shop</Text></Pressable><Pressable onPress={()=>router.push("/profile")}><Text style={s.navt}>●{"\n"}Profile</Text></Pressable></View>}
function Dashboard({role}:{role:string}){const title=role==="technician"?"Technician Dashboard":role==="parlour"?"Parlour Dashboard":"Seller Dashboard";return <View style={s.dash}><Text style={s.logo}>Nail Upp</Text><Text style={s.h}>{title}</Text><View style={s.stats}><Stat label="Today's earnings" value="UGX 120,000"/><Stat label="Bookings" value="3"/><Stat label="Pending" value="2"/></View><Text style={s.section}>Quick actions</Text>{["Profile & verification","Services & prices","Bookings / orders","Earnings","Reviews"].map(x=><Pressable key={x} style={s.menu}><Text style={{fontWeight:"800"}}>{x}</Text><Text>›</Text></Pressable>)}<Pressable style={s.btn} onPress={()=>router.replace("/")}><Text style={s.btnText}>Log out</Text></Pressable></View>}
function Stat({label,value}:{label:string;value:string}){return <View style={s.stat}><Text style={s.muted}>{label}</Text><Text style={s.statv}>{value}</Text></View>}
const s=StyleSheet.create({c:{padding:20,paddingBottom:110},logo:{fontSize:30,fontWeight:"900",fontStyle:"italic",color:colors.pink,marginBottom:8},loc:{color:colors.muted,marginBottom:24},h:{fontSize:24,fontWeight:"900",marginBottom:16},actions:{flexDirection:"row",gap:10,marginBottom:24},action:{flex:1,backgroundColor:"#fff",padding:14,borderRadius:16,alignItems:"center",...shadow},actionText:{fontSize:12,fontWeight:"800",textAlign:"center",marginTop:8},row:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:10},section:{fontSize:18,fontWeight:"900",marginTop:12,marginBottom:10},link:{color:colors.pink,fontWeight:"800"},card:{backgroundColor:"#fff",padding:14,borderRadius:16,marginBottom:10,flexDirection:"row",alignItems:"center",...shadow},avatar:{width:58,height:58,borderRadius:29,backgroundColor:colors.pinkLight,alignItems:"center",justifyContent:"center",marginRight:12},name:{fontWeight:"900"},rating:{color:colors.gold,marginTop:3},muted:{color:colors.muted,fontSize:12,marginTop:3},price:{fontWeight:"900",color:colors.pink,fontSize:12},nav:{position:"absolute",bottom:0,left:0,right:0,height:74,backgroundColor:"#fff",borderTopWidth:1,borderTopColor:colors.border,flexDirection:"row",justifyContent:"space-around",alignItems:"center"},navt:{textAlign:"center",fontSize:11,color:colors.muted},active:{textAlign:"center",fontSize:11,color:colors.pink,fontWeight:"900"},dash:{flex:1,padding:22,backgroundColor:colors.bg},stats:{flexDirection:"row",gap:10,marginVertical:18},stat:{flex:1,backgroundColor:"#fff",padding:14,borderRadius:14},statv:{fontWeight:"900",fontSize:16,marginTop:8},menu:{backgroundColor:"#fff",padding:18,borderRadius:14,marginBottom:10,flexDirection:"row",justifyContent:"space-between"},btn:{backgroundColor:colors.pink,padding:15,borderRadius:12,alignItems:"center",marginTop:20},btnText:{color:"#fff",fontWeight:"900"}});