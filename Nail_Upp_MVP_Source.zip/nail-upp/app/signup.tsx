import { useState } from "react";
import { router, useLocalSearchParams } from "expo-router";
import { View, Text, TextInput, Pressable, StyleSheet, Alert, ScrollView } from "react-native";
import { colors } from "@/lib/theme";
import { supabase } from "@/lib/supabase";

export default function Signup(){
 const {role="customer"}=useLocalSearchParams<{role?:string}>();
 const [name,setName]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [phone,setPhone]=useState(""); const [busy,setBusy]=useState(false);
 async function submit(){
  if(!name||!email||!password){Alert.alert("Missing information","Please enter your name, email and password.");return;}
  setBusy(true);
  if(supabase){
   const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name,role,phone}}});
   if(error){Alert.alert("Sign up failed",error.message);setBusy(false);return;}
   if(data.user) await supabase.from("profiles").upsert({id:data.user.id,full_name:name,phone,role});
  }
  setBusy(false); router.replace({pathname:"/home",params:{role}});
 }
 return <ScrollView contentContainerStyle={s.c}><Text style={s.h}>Create your {role} account</Text>
 {["Full name / business name","Phone number","Email","Password"].map((p,i)=><TextInput key={p} style={s.input} placeholder={p} secureTextEntry={i===3} keyboardType={i===1?"phone-pad":i===2?"email-address":"default"} value={[name,phone,email,password][i]} onChangeText={v=>[setName,setPhone,setEmail,setPassword][i](v)}/> )}
 <Pressable style={s.btn} onPress={submit}><Text style={s.btnText}>{busy?"Creating...":"Create Account"}</Text></Pressable>
 <Text style={s.note}>Business accounts can complete verification, services and portfolio setup from their dashboard.</Text>
 </ScrollView>
}
const s=StyleSheet.create({c:{padding:24,backgroundColor:colors.bg,flexGrow:1,justifyContent:"center"},h:{fontSize:28,fontWeight:"900",marginBottom:24},input:{backgroundColor:"#fff",borderWidth:1,borderColor:colors.border,borderRadius:12,padding:15,marginBottom:12},btn:{backgroundColor:colors.pink,padding:16,borderRadius:12,alignItems:"center",marginTop:8},btnText:{color:"#fff",fontWeight:"900"},note:{color:colors.muted,lineHeight:20,marginTop:18}});