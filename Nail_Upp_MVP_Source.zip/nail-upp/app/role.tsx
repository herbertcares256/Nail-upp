import { router } from "expo-router";
import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
import { colors, shadow } from "@/lib/theme";
import { Role } from "@/lib/types";

const roles:{key:Role; title:string; desc:string; icon:string}[]=[
 {key:"customer",title:"Customer",desc:"Find and book nail services",icon:"👤"},
 {key:"technician",title:"Nail Technician",desc:"Offer home nail services",icon:"💅"},
 {key:"parlour",title:"Nail Parlour",desc:"Register and manage your parlour",icon:"🏪"},
 {key:"seller",title:"Nail Materials Seller",desc:"Sell nail products and equipment",icon:"🛍️"}
];

export default function Role(){
 return <ScrollView contentContainerStyle={s.c}><Text style={s.h}>Who are you?</Text><Text style={s.sub}>Choose an account type to continue</Text>
 {roles.map(r=><Pressable key={r.key} style={s.card} onPress={()=>router.push({pathname:"/signup",params:{role:r.key}})}>
   <Text style={s.icon}>{r.icon}</Text><View style={{flex:1}}><Text style={s.title}>{r.title}</Text><Text style={s.desc}>{r.desc}</Text></View><Text style={s.arrow}>›</Text>
 </Pressable>)}</ScrollView>
}
const s=StyleSheet.create({c:{padding:24,backgroundColor:colors.bg,flexGrow:1},h:{fontSize:30,fontWeight:"900",marginTop:40,color:colors.text},sub:{color:colors.muted,marginBottom:24},card:{...shadow,backgroundColor:"#fff",padding:18,borderRadius:18,marginBottom:14,flexDirection:"row",alignItems:"center"},icon:{fontSize:30,marginRight:16},title:{fontWeight:"800",fontSize:17},desc:{color:colors.muted,marginTop:4},arrow:{fontSize:28,color:colors.pink}});