export type Role = "customer" | "technician" | "parlour" | "seller" | "admin";

export type Service = {
  id: string;
  name: string;
  price: number;
  duration_min: number;
};

export type Provider = {
  id: string;
  name: string;
  role: "technician" | "parlour";
  rating: number;
  reviews: number;
  distance_km: number;
  home_service?: boolean;
  location?: string;
  services: Service[];
};

export type Product = {
  id: string;
  name: string;
  price: number;
  rating: number;
  category: string;
  image?: string;
};