export const colors = {
  pink: "#F20B70",
  pinkDark: "#C9085C",
  pinkLight: "#FFE5F0",
  purple: "#8B5CF6",
  gold: "#F4B400",
  green: "#18A66A",
  text: "#17151A",
  muted: "#77727B",
  bg: "#FFF9FC",
  card: "#FFFFFF",
  border: "#EEE7EC",
  danger: "#D92D20"
};

export const shadow = {
  shadowColor: "#000",
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.06,
  shadowRadius: 8,
  elevation: 2
};