import { Product, Provider } from "./types";

export const services = [
  { id: "manicure", name: "Manicure", price: 25000, duration_min: 45 },
  { id: "pedicure", name: "Pedicure", price: 30000, duration_min: 60 },
  { id: "acrylic", name: "Acrylic Nails", price: 45000, duration_min: 90 },
  { id: "gel", name: "Gel Nails", price: 35000, duration_min: 75 },
  { id: "extensions", name: "Extensions", price: 55000, duration_min: 120 },
  { id: "nail-art", name: "Nail Art", price: 15000, duration_min: 30 }
];

export const providers: Provider[] = [
  { id:"tech-1", name:"Sarah Nail Artist", role:"technician", rating:4.9, reviews:126, distance_km:0.8, home_service:true, location:"Kireka", services },
  { id:"tech-2", name:"Sharon Beauty", role:"technician", rating:4.8, reviews:99, distance_km:1.2, home_service:true, location:"Ntinda", services },
  { id:"tech-3", name:"Tracy Nails", role:"technician", rating:4.7, reviews:87, distance_km:1.5, home_service:true, location:"Bugolobi", services },
  { id:"par-1", name:"Nails by Grace", role:"parlour", rating:4.8, reviews:245, distance_km:1.4, location:"Kireka", services },
  { id:"par-2", name:"Elegance Nails", role:"parlour", rating:4.7, reviews:196, distance_km:2.0, location:"Ntinda", services },
  { id:"par-3", name:"Royal Nails Salon", role:"parlour", rating:4.6, reviews:183, distance_km:2.5, location:"Bugolobi", services }
];

export const products: Product[] = [
  { id:"p1", name:"Professional UV Lamp", price:85000, rating:4.7, category:"Tools" },
  { id:"p2", name:"Acrylic Powder Clear", price:35000, rating:4.6, category:"Acrylic" },
  { id:"p3", name:"Gel Polish", price:25000, rating:4.8, category:"Gel" },
  { id:"p4", name:"Nail Tips Pack", price:20000, rating:4.5, category:"Tips" },
  { id:"p5", name:"Nail Art Brush Set", price:30000, rating:4.7, category:"Tools" }
];

export const money = (n:number) => `UGX ${n.toLocaleString("en-UG")}`;